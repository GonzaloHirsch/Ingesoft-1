package com.hirsch.gonzalo.ustudy.DataTypes;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Contact {

    private String email;
    private String name;
    private String chatID;

    public Contact(String email, String name, String chatID){
        this.email = email;
        this.name = name;
        this.chatID = chatID;
    }

    public Contact(Map<String, Object> data){
        this.email = (String)data.get("email");
        this.name = (String)data.get("name");
        this.chatID = (String)data.get("chatID");
    }

    public Contact(){

    }

    public String getChatID() {
        return chatID;
    }

    public void setChatID(String chatID) {
        this.chatID = chatID;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public static List<String> GetContactIDs(List<Contact> contacts){
        List<String> ids = new ArrayList<>();
        for (Contact contact : contacts) {
            ids.add(contact.getChatID());
        }
        return ids;
    }
}
