package com.hirsch.gonzalo.ustudy.Interfaces;

import com.hirsch.gonzalo.ustudy.DataTypes.Contact;

import java.util.List;

public interface ContactAccessor {
    public void ContactsRetrieved(List<Contact> contacts);
}
