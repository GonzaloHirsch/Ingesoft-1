package com.hirsch.gonzalo.ustudy.DataTypes;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class StudyGroup {

    private List<User> users;
    private String subject;
    private long creationMillis;
    private String groupID;

    public StudyGroup(){

    }

    public String getGroupID() {
        return groupID;
    }

    public List<User> getUsers() {
        return users;
    }

    public void setUsers(List<User> users) {
        this.users = users;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public StudyGroup(Map<String, Object> data){
        this.users = (List<User>) data.get("users");
        this.subject = (String)data.get("subject");
        this.groupID = (String)data.get("groupID");
        this.creationMillis = ((Number)data.get("creationMillis")).longValue();
    }

    public StudyGroup(List<User> users, String subject){
        this.creationMillis = Calendar.getInstance().getTimeInMillis();
        this.users = users;
        this.groupID = GetGroupID(subject, creationMillis);
        this.subject = subject;
    }

    public static String GetGroupID(String subject, long creationMillis){
        return String.valueOf(Objects.hash(subject, creationMillis));
    }

    @Override
    public int hashCode() {
        return Objects.hash(subject, users);
    }
}
