package com.hirsch.gonzalo.ustudy.Fragments;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.hirsch.gonzalo.ustudy.DataTypes.Chat;
import com.hirsch.gonzalo.ustudy.DataTypes.Contact;
import com.hirsch.gonzalo.ustudy.DataTypes.Teacher;
import com.hirsch.gonzalo.ustudy.DataTypes.User;
import com.hirsch.gonzalo.ustudy.HelperClasses.DataCache;
import com.hirsch.gonzalo.ustudy.HelperClasses.DatabaseHelper;
import com.hirsch.gonzalo.ustudy.HelperClasses.ToolbarHelper;
import com.hirsch.gonzalo.ustudy.Interfaces.ContactAccessor;
import com.hirsch.gonzalo.ustudy.Interfaces.MessageAccessor;
import com.hirsch.gonzalo.ustudy.Interfaces.NavigationHost;
import com.hirsch.gonzalo.ustudy.Interfaces.UserAccessor;
import com.hirsch.gonzalo.ustudy.Adapters.ProductCardRecyclerViewAdapter;
import com.hirsch.gonzalo.ustudy.ProductGridItemDecoration;
import com.hirsch.gonzalo.ustudy.R;

import java.util.HashMap;
import java.util.List;

public class MainMenuFragment extends Fragment implements UserAccessor, ContactAccessor, MessageAccessor {

    private List<Teacher> teachers;
    private User user;
    private FirebaseAuth mAuth;

    private View fragmentView;
    private DataCache dataCache;

    @Override
    public void UserRetrieved(User user) {
        //Store the user in the cache
        dataCache.setUser(user);
    }

    @Override
    public void TeachersRetrieved(List<Teacher> teachers) {
        SetUpGrid(fragmentView, teachers);
        //Store the teachers in the cache
        dataCache.setTeachers(teachers);
    }

    @Override
    public void onCreate(Bundle savedInstance){
        super.onCreate(savedInstance);
        setHasOptionsMenu(true);
    }

    @Override
    public void onStart() {
        super.onStart();
        //Initialize the firebase app
        FirebaseApp.initializeApp(getContext());
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.main_menu_fragment, container, false);

        fragmentView = view;

        dataCache = (DataCache) getContext().getApplicationContext();

        // Get the authentication instance
        mAuth = FirebaseAuth.getInstance();

        //Set up the toolbar
        ToolbarHelper.SetUpToolbarNavigation(view, (NavigationHost) getActivity(), getContext() );
        ToolbarHelper.SetUpToolbar(view, getContext(), (AppCompatActivity) getActivity(), R.id.product_grid);

        //Check if there is data in the cache
        //If there is data, it uses that data to avoid asking for it and delaying everything
        //If there is no data, it looks for it in the database
        if (dataCache.getTeachers() == null){
            new DatabaseHelper(getContext()).GetTeachers(this);
        } else {
            SetUpGrid(view, dataCache.getTeachers());
        }

        //Check if there are contacts in the cache
        //If there are no contacts, retrieve them and store them
        if (dataCache.getContacts() == null){
            new DatabaseHelper(getContext()).GetUserContacts(mAuth.getCurrentUser().getEmail(), this);
        }

        return view;
    }

    private void SetUpGrid(View view, List<Teacher> teachers){
        RecyclerView recyclerView = view.findViewById(R.id.recycler_view);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(), 3, GridLayoutManager.HORIZONTAL, false));
        ProductCardRecyclerViewAdapter adapter = new ProductCardRecyclerViewAdapter(teachers,getContext(), getActivity(), mAuth.getCurrentUser().getEmail(), mAuth.getCurrentUser().getDisplayName());
        recyclerView.setAdapter(adapter);

        int largePadding = getResources().getDimensionPixelSize(R.dimen.product_grid_spacing);
        int smallPadding = getResources().getDimensionPixelSize(R.dimen.product_grid_spacing_small);
        recyclerView.addItemDecoration(new ProductGridItemDecoration(largePadding, smallPadding));
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater menuInflater){
        menuInflater.inflate(R.menu.toolbar_menu, menu);
        super.onCreateOptionsMenu(menu, menuInflater);
    }

    @Override
    public void ContactsRetrieved(List<Contact> contacts) {
        //Recover all the contacts and set them in cache
        dataCache.setContacts(contacts);
        //Recover all the chat ids
        List<String> ids = Contact.GetContactIDs(contacts);
        //Recover all the chats and asign them to the hashmap
        new DatabaseHelper(getContext()).GetAllUserChats(ids, this);
    }

    @Override
    public void MessagesRetrieved(Chat chat) {
        if (dataCache.getChats() == null){
            HashMap<String, Chat> chatHashMap = new HashMap<>();
            chatHashMap.put(chat.getChatID(), chat);
            dataCache.setChats(chatHashMap);
        } else {
            dataCache.AddChat(chat);
        }
    }
}
