package com.hirsch.gonzalo.ustudy.Fragments;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.hirsch.gonzalo.ustudy.DataTypes.Teacher;
import com.hirsch.gonzalo.ustudy.DataTypes.User;
import com.hirsch.gonzalo.ustudy.HelperClasses.DataCache;
import com.hirsch.gonzalo.ustudy.HelperClasses.DatabaseHelper;
import com.hirsch.gonzalo.ustudy.HelperClasses.ToolbarHelper;
import com.hirsch.gonzalo.ustudy.Interfaces.NavigationHost;
import com.hirsch.gonzalo.ustudy.Interfaces.UserAccessor;
import com.hirsch.gonzalo.ustudy.R;

import java.util.List;

public class ProfileEditFragment extends Fragment implements UserAccessor {

    private User user;
    private List<Teacher> teachers;

    private FirebaseAuth mAuth;
    private FirebaseUser authenticatedUser;

    private TextInputLayout fullnameLayout;
    private TextInputLayout averageLayout;
    private TextInputEditText fullnameEditText;
    private TextInputEditText averageEditText;

    private DataCache dataCache;

    @Override
    public void UserRetrieved(User user) {
        //Store the user data
        this.user = user;

        //Update the UI accordingly
        UpdateUI(user);

        //Set up the values
        SetUpFragment(user);
    }

    @Override
    public void TeachersRetrieved(List<Teacher> teachers) {
        this.teachers = teachers;
    }

    @Override
    public void onCreate(Bundle savedInstance){
        super.onCreate(savedInstance);
        setHasOptionsMenu(true);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater menuInflater){
        menuInflater.inflate(R.menu.no_icons_menu, menu);
        super.onCreateOptionsMenu(menu, menuInflater);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //Layout inflater for the view
        final View view = inflater.inflate(R.layout.profile_edit_fragment, container, false);

        mAuth = FirebaseAuth.getInstance();

        dataCache = (DataCache) getContext().getApplicationContext();

        // Get the signed user
        authenticatedUser = mAuth.getCurrentUser();

        //Set up the toolbar
        ToolbarHelper.SetUpToolbarNavigation(view, (NavigationHost) getActivity(), getContext() );
        ToolbarHelper.SetUpToolbar(view, getContext(), (AppCompatActivity) getActivity(), R.id.layout_profile);

        fullnameLayout = view.findViewById(R.id.profile_edit_fullname_layout);
        averageLayout = view.findViewById(R.id.profile_edit_average_layout);
        fullnameEditText = view.findViewById(R.id.profile_edit_fullname_editText);
        averageEditText = view.findViewById(R.id.profile_edit_average_editText);

        //Recover the signed user info
        if (dataCache.getUser() == null){
            new DatabaseHelper(getContext()).GetUser(authenticatedUser.getEmail(), this);
        } else {
            //Store the user data
            this.user = dataCache.getUser();

            //Update the UI accordingly
            UpdateUI(user);

            //Set up the values
            SetUpFragment(user);
        }

        view.findViewById(R.id.be_teacher_text).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Sets the value for teacher
                user.setTeacher(true);
                //Updates the database
                new DatabaseHelper(getContext()).UpdateUser(user);
                //Updates the UI
                UpdateUI(user);

                ((TextView)view.findViewById(R.id.message_text)).setVisibility(View.VISIBLE);
                ((TextView)view.findViewById(R.id.message_text)).setText(getString(R.string.informationUpdated));
            }
        });
        view.findViewById(R.id.stop_being_teacher_text).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Sets the value for teacher
                user.setTeacher(false);
                //Updates the database
                new DatabaseHelper(getContext()).UpdateUser(user);
                //Updates the UI
                UpdateUI(user);

                ((TextView)view.findViewById(R.id.message_text)).setVisibility(View.VISIBLE);
                ((TextView)view.findViewById(R.id.message_text)).setText(getString(R.string.informationUpdated));
            }
        });
        view.findViewById(R.id.save_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Validate()){
                    user.setAverage(Double.parseDouble(averageEditText.getText().toString()));
                    user.setFullName(fullnameEditText.getText().toString());
                    new DatabaseHelper(getContext()).UpdateUser(user);
                    ((TextView)view.findViewById(R.id.message_text)).setVisibility(View.VISIBLE);
                    ((TextView)view.findViewById(R.id.message_text)).setText(getString(R.string.informationUpdated));
                }
            }
        });
        view.findViewById(R.id.add_subjects_text).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((NavigationHost)getActivity()).navigateTo( new ManageSubjectsFragment(), false);
            }
        });

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        //Initialize the firebase app
        FirebaseApp.initializeApp(getContext());
    }

    private void SetUpFragment(User user){
        View view = getView();
        if (view != null){
            fullnameEditText.setText(user.getFullName());
            averageEditText.setText(String.valueOf(user.getAverage()));
        }
    }

    private boolean Validate(){
        boolean result = true;
        if (fullnameEditText.getText() != null){
            if(fullnameEditText.getText().toString().equals("")){
                fullnameLayout.setError(getString(R.string.ERROR_no_name));
                result = false;
            } else {
                fullnameLayout.setErrorEnabled(false);
            }
        } else {
            result = false;
            fullnameLayout.setError(getString(R.string.ERROR_no_name));
        }
        if (averageEditText.getText() != null){
            if(averageEditText.getText().toString().equals("")){
                result = false;
                averageLayout.setError(getString(R.string.ERROR_no_average));
            } else if (Double.parseDouble(averageEditText.getText().toString()) < 0 || Double.parseDouble(averageEditText.getText().toString()) > 10){
                result = false;
                averageLayout.setError(getString(R.string.ERROR_invalid_average));
            } else {
                averageLayout.setErrorEnabled(false);
            }
        } else {
            result = false;
            averageLayout.setError(getString(R.string.ERROR_no_average));
        }
        return result;
    }

    private void UpdateUI(User user){
        View view = getView();
        if (view != null){
            if (user.isTeacher()){
                view.findViewById(R.id.be_teacher_text).setVisibility(View.GONE);
                view.findViewById(R.id.stop_being_teacher_text).setVisibility(View.VISIBLE);
                view.findViewById(R.id.add_subjects_text).setVisibility(View.VISIBLE);
            } else {
                view.findViewById(R.id.be_teacher_text).setVisibility(View.VISIBLE);
                view.findViewById(R.id.stop_being_teacher_text).setVisibility(View.GONE);
                view.findViewById(R.id.add_subjects_text).setVisibility(View.GONE);
            }
        }
    }
}
