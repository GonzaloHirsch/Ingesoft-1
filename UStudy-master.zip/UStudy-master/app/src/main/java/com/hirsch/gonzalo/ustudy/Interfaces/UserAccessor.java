package com.hirsch.gonzalo.ustudy.Interfaces;

import com.hirsch.gonzalo.ustudy.DataTypes.Teacher;
import com.hirsch.gonzalo.ustudy.DataTypes.User;

import java.util.List;

public interface UserAccessor {
    public void UserRetrieved(User user);
    public void TeachersRetrieved(List<Teacher> teachers);
}
