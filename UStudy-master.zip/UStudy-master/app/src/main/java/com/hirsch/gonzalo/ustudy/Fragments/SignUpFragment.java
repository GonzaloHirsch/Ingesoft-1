package com.hirsch.gonzalo.ustudy.Fragments;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.button.MaterialButton;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseAuthWeakPasswordException;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.hirsch.gonzalo.ustudy.Items.CustomSpinner;
import com.hirsch.gonzalo.ustudy.DataTypes.User;
import com.hirsch.gonzalo.ustudy.HelperClasses.DatabaseHelper;
import com.hirsch.gonzalo.ustudy.HelperClasses.Validations;
import com.hirsch.gonzalo.ustudy.Interfaces.NavigationHost;
import com.hirsch.gonzalo.ustudy.R;

public class SignUpFragment extends Fragment {

    //Firebase authentication
    private FirebaseAuth mAuth;
    //Tag for the log
    private final String TAG = "SignUpFragment";

    private TextInputEditText nameEditText;
    private TextInputEditText emailEditText;
    private TextInputEditText passwordEditText;
    private TextInputEditText confirmPasswordEditText;
    private TextInputLayout nameLayout;
    private TextInputLayout emailLayout;
    private TextInputLayout passwordLayout;
    private TextInputLayout confirmPasswordLayout;
    private CustomSpinner dropdown;
    private TextView errorLabel;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        //Layout inflater for the view
        View view = inflater.inflate(R.layout.sign_up_fragment, container, false);

        //Buttons
        MaterialButton enterButton = view.findViewById(R.id.enter_button);
        MaterialButton backButton = view.findViewById(R.id.back_button);
        //Fields
        nameEditText = view.findViewById(R.id.full_name_content);
        emailEditText = view.findViewById(R.id.username_content);
        passwordEditText = view.findViewById(R.id.password_content);
        confirmPasswordEditText = view.findViewById(R.id.confirm_password_content);
        nameLayout = view.findViewById(R.id.full_name_layout);
        emailLayout = view.findViewById(R.id.username_layout);
        passwordLayout = view.findViewById(R.id.password_layout);
        confirmPasswordLayout = view.findViewById(R.id.confirm_password_layout);
        dropdown = view.findViewById(R.id.dropdown_subjects);
        errorLabel = view.findViewById(R.id.error_message);

        enterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CreateUser(v);
            }
        });

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((NavigationHost)getActivity()).navigateTo(new SignInFragment(), false);
            }
        });

        //Retrieves the instance of the authentication
        mAuth = FirebaseAuth.getInstance();

        SetUpDropdown(view, getActivity());

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        //Initialize the firebase app
        FirebaseApp.initializeApp(getContext());
    }

    private void SetUpDropdown(View view, Context context){
        ArrayAdapter adapter = new ArrayAdapter<>(context, R.layout.dropdown_item_selected, getResources().getStringArray(R.array.universities));
        adapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);

        final CustomSpinner spinner = view.findViewById(R.id.dropdown_subjects);
        spinner.setAdapter(adapter);
        spinner.setSpinnerEventsListener(new CustomSpinner.OnSpinnerEventsListener() {
            public void onSpinnerOpened() {
                spinner.setSelected(true);
            }
            public void onSpinnerClosed() {
                spinner.setSelected(false);
            }
        });
    }

    //---------------------------Validations---------------------------

    private void CreateUser(View view){
        //Getting the important fields
        String email = "";
        String password = "";
        String confirmPassword = "";
        if (emailEditText.getText() != null)
            email = emailEditText.getText().toString();
        if (passwordEditText.getText() != null)
            password = passwordEditText.getText().toString();
        if (confirmPasswordEditText.getText() != null)
            confirmPassword = confirmPasswordEditText.getText().toString();

        if (IsInformationValid(view, email, password, confirmPassword)){
            SignUpUser(email, password);
        }
    }

    private boolean IsInformationValid(View view, String email, String password, String confirmPassword){
        boolean isValid = true;

        //Full name validation
        if (nameEditText.getText() == null || nameEditText.getText().toString().equals("")){
            isValid = false;
            nameLayout.setError(getString(R.string.ERROR_no_name));
            nameEditText.requestFocus();
        } else {
            nameLayout.setErrorEnabled(false);
        }

        //Email validation
        if (!Validations.IsEmailValid(email)){
            isValid = false;
            emailLayout.setError(getString(R.string.ERROR_invalid_email));
            emailEditText.requestFocus();
        } else if (email.equals("")){
            isValid = false;
            emailLayout.setError(getString(R.string.ERROR_no_user));
            emailEditText.requestFocus();
        } else {
            emailLayout.setErrorEnabled(false);
        }

        if (!Validations.ValidatePassword(password)){
            isValid = false;
            passwordLayout.setError(getString(R.string.ERROR_password_content));
            passwordEditText.requestFocus();
            confirmPasswordLayout.setError(getString(R.string.ERROR_password_content));
        } else if (!Validations.IsPasswordConfirmationValid(password, confirmPassword)){
            isValid = false;
            passwordLayout.setError(getString(R.string.ERROR_passwords_dont_match));
            passwordEditText.requestFocus();
            confirmPasswordLayout.setError(getString(R.string.ERROR_passwords_dont_match));
        } else {
            passwordLayout.setErrorEnabled(false);
            confirmPasswordLayout.setErrorEnabled(false);
        }

        //University Dropdown
        if(dropdown.getSelectedItemPosition() == 0 || dropdown.getSelectedItemPosition() == AdapterView.INVALID_POSITION){
            isValid = false;
            errorLabel.setVisibility(View.VISIBLE);
            dropdown.requestFocus();
            errorLabel.setText(getText(R.string.ERROR_no_item_selected));
        } else {
            errorLabel.setVisibility(View.GONE);
        }

        return isValid;
    }

    //Creates a new instance of user and adds it to the database
    private User CreateUser(String email, String university, String fullName){
        User user = new User(email, university, fullName);

        new DatabaseHelper(getContext()).CreateUser(user);

        return user;
    }

    private void SignUpUser(final String email, String password){
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d(TAG, "createUserWithEmail:success");
                            //Create the user in the database
                            CreateUser(email, (String)dropdown.getSelectedItem(), nameEditText.getText().toString());
                            //Set the name for the messages part
                            mAuth.getCurrentUser().updateProfile(new UserProfileChangeRequest.Builder().setDisplayName(nameEditText.getText().toString()).build());
                            //Navigate to the sign in part
                            ((NavigationHost)getActivity()).navigateTo(new SignInFragment(), false);
                        } else {
                            Log.w(TAG, "createUserWithEmail:failure", task.getException());
                            if (task.getException() != null){
                                //Determine the type of exception to get focus there
                                try {
                                    throw task.getException();
                                } catch(FirebaseAuthWeakPasswordException e) {
                                    passwordLayout.setError(getString(R.string.ERROR_weak_password));
                                    confirmPasswordLayout.setError(getString(R.string.ERROR_weak_password));
                                    passwordEditText.requestFocus();
                                } catch(FirebaseAuthInvalidCredentialsException e) {
                                    emailLayout.setError(getString(R.string.ERROR_invalid_email));
                                    emailEditText.requestFocus();
                                } catch(FirebaseAuthUserCollisionException e) {
                                    emailLayout.setError(getString(R.string.ERROR_used_email));
                                    emailEditText.requestFocus();
                                } catch(Exception e) {
                                    Log.e(TAG, e.getMessage());
                                }
                            } else {
                                Toast.makeText(getActivity(), "Authentication failed.",
                                        Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                });
    }
}
