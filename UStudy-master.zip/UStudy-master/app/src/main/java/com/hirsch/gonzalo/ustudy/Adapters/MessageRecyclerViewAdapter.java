package com.hirsch.gonzalo.ustudy.Adapters;

import android.app.Activity;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.hirsch.gonzalo.ustudy.DataTypes.ChatMessage;
import com.hirsch.gonzalo.ustudy.ViewHolders.MessageViewHolder;
import com.hirsch.gonzalo.ustudy.R;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class MessageRecyclerViewAdapter extends RecyclerView.Adapter<MessageViewHolder> {

    private List<ChatMessage> messages;
    private Activity activity;
    private String userEmail;

    private final int MESSAGE_SENT = 1;
    private final int MESSAGE_RECEIVED = 2;

    public MessageRecyclerViewAdapter(List<ChatMessage> messages, Activity activity, String userEmail) {
        this.messages = messages;
        this.activity = activity;
        this.userEmail = userEmail;
    }

    @NonNull
    @Override
    public MessageViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        if (viewType == MESSAGE_SENT){
            View layoutView = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.message_sent, viewGroup, false);
            return new MessageViewHolder(layoutView);
        } else {
            View layoutView = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.message_received, viewGroup, false);
            return new MessageViewHolder(layoutView);
        }
    }

    public void MessageWasAdded(ChatMessage message){
        messages.add(message);
        this.notifyItemInserted(messages.size() - 1);
        this.notifyDataSetChanged();
    }

    public void MessageWasAdded(List<ChatMessage> messages){
//        for (ChatMessage message : messages) {
//            this.messages.add(message);
//
//        }
        this.notifyItemInserted(this.messages.size() - 1);
        this.notifyDataSetChanged();
    }

    @Override
    public int getItemViewType(int position) {
        ChatMessage message = messages.get(position);

        if (message.getSender().equals(userEmail)) {
            // If the current user is the sender of the message
            return MESSAGE_SENT;
        } else {
            // If some other user sent the message
            return MESSAGE_RECEIVED;
        }
    }

    @Override
    public void onBindViewHolder(@NonNull MessageViewHolder messageViewHolder, int i) {
        if (messages != null && i < messages.size()){
            ChatMessage message = messages.get(i);

            DateFormat df = new SimpleDateFormat("dd/MM HH:mm", Locale.FRANCE);
            Calendar calendar = Calendar.getInstance();
            calendar.setTimeInMillis(message.getMessageTime());
            String date = df.format(calendar.getTime());

            messageViewHolder.body.setText(message.getMessageText());
            messageViewHolder.time.setText(date);
        }
    }

    @Override
    public int getItemCount()  {
        return messages != null ? messages.size() : 0;
    }
}
