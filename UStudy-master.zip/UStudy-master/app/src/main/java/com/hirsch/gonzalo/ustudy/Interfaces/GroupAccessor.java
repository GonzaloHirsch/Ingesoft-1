package com.hirsch.gonzalo.ustudy.Interfaces;

import com.hirsch.gonzalo.ustudy.DataTypes.StudyGroup;

import java.util.List;

public interface GroupAccessor {
    public void GroupsRetrieved(List<StudyGroup> groups);
    public void GroupRetrieved(StudyGroup groups);
}
