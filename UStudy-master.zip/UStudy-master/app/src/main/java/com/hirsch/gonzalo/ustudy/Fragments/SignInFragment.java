package com.hirsch.gonzalo.ustudy.Fragments;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.button.MaterialButton;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthActionCodeException;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseAuthWeakPasswordException;
import com.google.firebase.auth.FirebaseUser;
import com.hirsch.gonzalo.ustudy.Interfaces.NavigationHost;
import com.hirsch.gonzalo.ustudy.R;


public class SignInFragment extends Fragment {

    //Firebase authentication
    private FirebaseAuth mAuth;
    //Tag for the log
    private final String TAG = "SignInFragment";

    //Layouts and contents
    private TextInputLayout passwordLayout;
    private TextInputLayout usernameLayout;
    private TextInputEditText passwordContent;
    private TextInputEditText usernameContent;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        //Layout inflater for the view
        View view = inflater.inflate(R.layout.sign_in_fragment, container, false);

        //Retrieves the instance of the authentication
        mAuth = FirebaseAuth.getInstance();

        //Retrieving elements from the view
        //Text elements
        passwordLayout = view.findViewById(R.id.password_layout);
        passwordContent = view.findViewById(R.id.password_content);
        usernameLayout = view.findViewById(R.id.username_layout);
        usernameContent = view.findViewById(R.id.username_content);
        //Clickable elements
        TextView createAccountText = view.findViewById(R.id.create_account);
        TextView forgotPasswordText = view.findViewById(R.id.forgot_password);
        MaterialButton enterButton = view.findViewById(R.id.enter_button);

        //Listeners
        enterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SignInUserAttempt();
            }
        });
        createAccountText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CreateAccount();
            }
        });
        forgotPasswordText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ForgotPassword();
            }
        });

        return view;
    }

    //Validates format and content
    private boolean ValidateSignInFormat(String username, String password){
        boolean isValid = true;
        //In case the user is empty
        if (username.equals("")){
            isValid = false;
            usernameLayout.setError(getString(R.string.ERROR_no_user));
        } else {
            usernameLayout.setErrorEnabled(false);
        }
        //In case the password is empty
        if (password.equals("")){
            isValid = false;
            passwordLayout.setError(getString(R.string.ERROR_no_password));
        }
        else {
            passwordLayout.setErrorEnabled(false);
        }
        return isValid;
    }

    private void SignInUserAttempt(){
        boolean error = false;
        String username = "";
        String password = "";
        //Verify if the contents are null
        if (usernameContent.getText() != null){
            username = usernameContent.getText().toString();
        } else {
            error = true;
            usernameLayout.setError(getString(R.string.ERROR_no_user));
            usernameContent.requestFocus();
        }
        if (passwordContent.getText() != null){
            password = passwordContent.getText().toString();
        } else {
            error = true;
            passwordLayout.setError(getString(R.string.ERROR_no_password));
            passwordContent.requestFocus();
        }

        //If everything is valid, it tries to log in
        if (!error && ValidateSignInFormat(username, password)){
            mAuth.signInWithEmailAndPassword(username, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()) {
                        // Sign in success, update UI with the signed-in user's information
                        Log.d(TAG, "signInWithEmail:success");
                        FirebaseUser user = mAuth.getCurrentUser();
                        updateUI(user);
                    } else {
                        // If sign in fails, display a message_sent to the user.
                        Log.w(TAG, "signInWithEmail:failure", task.getException());
                        if (task.getException() != null){
                            //Determine the type of exception to get focus there
                            try {
                                throw task.getException();
                            } catch(FirebaseAuthInvalidCredentialsException e) {
                                passwordLayout.setError(getString(R.string.ERROR_invalid_credentials));
                                usernameLayout.setError(getString(R.string.ERROR_invalid_credentials));
                            } catch(FirebaseAuthActionCodeException e) {
                                passwordLayout.setError(getString(R.string.ERROR_invalid_login));
                                usernameLayout.setError(getString(R.string.ERROR_invalid_login));
                            } catch(Exception e) {
                                Log.e(TAG, e.getMessage());
                            }
                        } else {
                            //Show a message_sent to the user to tell them it failed to log in
                            Toast.makeText(getActivity(), "Authentication failed.",
                                    Toast.LENGTH_SHORT).show();
                        }
                        updateUI(null);
                    }
                }
            });
        }
    }

    @Override
    public void onStart() {
        super.onStart();

        //Initialize the firebase app
        FirebaseApp.initializeApp(getContext());

        // Check if user is signed in (non-null) and update UI accordingly.
        FirebaseUser currentUser = mAuth.getCurrentUser();
        updateUI(currentUser);
    }

    private void updateUI(FirebaseUser currentUser) {
        //In case the user is signed in, it goes straight through to the main menu
        if (currentUser != null){
            //Navigates to the main menu because the user is already signed in
            ((NavigationHost) getActivity()).navigateTo(new MainMenuFragment(), false);
        }
        //In case the user is not signed in, it stays in the fragment to make sure it logs in
    }

    private void CreateAccount(){
        ((NavigationHost) getActivity()).navigateTo(new SignUpFragment(), false);
    }

    private void ForgotPassword(){
        ((NavigationHost) getActivity()).navigateTo(new ForgotPasswordFragment(), false);
    }
}
