package com.hirsch.gonzalo.ustudy.DataTypes;

import com.hirsch.gonzalo.ustudy.HelperClasses.DatabaseHelper;

import java.util.Date;
import java.util.List;
import java.util.Map;

public class ChatMessage implements Comparable<ChatMessage>{

    private String sender;
    private String recipient;
    private String messageText;
    private String messageUser;
    private long messageTime;
    private String id;

    public ChatMessage(String messageText, String messageUser, String sender, String recipient) {
        this.messageText = messageText;
        this.messageUser = messageUser;
        this.sender = sender;
        this.recipient = recipient;

        // Initialize to current time
        this.messageTime = new Date().getTime();
        this.id = String.valueOf(Chat.GetChatID(sender, recipient));
    }

    public ChatMessage(Map<String, Object> data){
        this.sender = (String)data.get("sender");
        this.recipient = (String)data.get("recipient");
        this.messageTime = (long)data.get("messageTime");
        this.messageText = (String)data.get("messageText");
        this.messageUser = (String)data.get("messageUser");
        this.id = (String)data.get("id");
    }

    public ChatMessage(){

    }

    public String getSender() {
        return sender;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getId() {
        return id;
    }

    public String getMessageText() {
        return messageText;
    }

    public void setMessageText(String messageText) {
        this.messageText = messageText;
    }

    public String getMessageUser() {
        return messageUser;
    }

    public void setMessageUser(String messageUser) {
        this.messageUser = messageUser;
    }

    public long getMessageTime() {
        return messageTime;
    }

    public void setMessageTime(long messageTime) {
        this.messageTime = messageTime;
    }

    @Override
    public int compareTo(ChatMessage o) {
        return messageTime > o.messageTime ? 1 : 0;
    }
}
