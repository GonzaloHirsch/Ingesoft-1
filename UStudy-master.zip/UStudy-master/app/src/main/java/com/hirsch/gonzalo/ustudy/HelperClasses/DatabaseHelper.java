package com.hirsch.gonzalo.ustudy.HelperClasses;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;
import com.hirsch.gonzalo.ustudy.DataTypes.Chat;
import com.hirsch.gonzalo.ustudy.DataTypes.ChatMessage;
import com.hirsch.gonzalo.ustudy.DataTypes.Contact;
import com.hirsch.gonzalo.ustudy.DataTypes.StudyGroup;
import com.hirsch.gonzalo.ustudy.DataTypes.Teacher;
import com.hirsch.gonzalo.ustudy.DataTypes.User;
import com.hirsch.gonzalo.ustudy.Interfaces.ContactAccessor;
import com.hirsch.gonzalo.ustudy.Interfaces.GroupAccessor;
import com.hirsch.gonzalo.ustudy.Interfaces.MessageAccessor;
import com.hirsch.gonzalo.ustudy.Interfaces.SubjectAccessor;
import com.hirsch.gonzalo.ustudy.Interfaces.UserAccessor;
import com.hirsch.gonzalo.ustudy.Adapters.MessageRecyclerViewAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Nullable;

public class DatabaseHelper {

    private final String TAG = "DatabaseHelper";
    private static final long PRIME = 31;

    private FirebaseFirestore db;

    public DatabaseHelper(Context context){
        //Initialize the app
        FirebaseApp.initializeApp(context);
        FirebaseFirestore.setLoggingEnabled(true);
        //Get an instance of the database
        this.db = FirebaseFirestore.getInstance();
    }

    //----------------------------USERS---------------------------------
    public void CreateUser(User user){
        //Add the user to the database
        db.collection("Users").document(user.getEmail()).set(user)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                Log.d(TAG, "User successfully created!");
            }
        })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error creating user", e);
                    }
                });
    }

    public void GetUser(String email, final UserAccessor accessor){
        DocumentReference docRef = db.collection("Users").document(email);
        //User retrievedUser;
        docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        Log.d(TAG, "DocumentSnapshot data: " + document.getData());
                        User result = new User(document.getData());
                        accessor.UserRetrieved(result);
                    } else {
                        Log.d(TAG, "No such document");
                    }
                } else {
                    Log.d(TAG, "get failed with ", task.getException());
                }
            }
        });
    }

    public void GetSubjects(final SubjectAccessor accessor){
        CollectionReference colRef = db.collection("Subjects");
        //User retrievedUser;
        Query query = colRef.whereEqualTo("active", true);

        query.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()){
                    Log.d(TAG, "Subject query successful");
                    QuerySnapshot query = task.getResult();
                    if (query != null && !query.isEmpty()) {
                        Log.d(TAG, "Retrieved subjects");
                        List<String> subjects = new ArrayList<>();
                        for(DocumentSnapshot ds : query.getDocuments()){
                            if(ds.getData() != null)
                                subjects.add(ds.getData().get("name").toString());
                        }
                        accessor.SubjectsRetrieved(subjects);
                    } else {
                        Log.d(TAG, "No such subjects");
                    }
                } else {
                    Log.d(TAG, "Subject query failed with ", task.getException());
                }
            }
        });
    }

    public void UpdateUser(User user){
        db.collection("Users").document(user.getEmail()).update("teacher", user.isTeacher(), "subjects", user.getSubjects(), "average", user.getAverage())
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "User successfully updated!");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error updating user", e);
                    }
                });
    }

    public void GetTeachers(final UserAccessor accessor){
        // Create a reference to the cities collection
        CollectionReference usersRef = db.collection("Users");

        // Create a query against the collection.
        Query query = usersRef.whereEqualTo("teacher", true);

        query.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    QuerySnapshot query = task.getResult();
                    if (query != null && !query.isEmpty()) {
                        Log.d(TAG, "Retrieved users");
                        List<User> users = new ArrayList<>();
                        for(DocumentSnapshot ds : query.getDocuments()){
                            users.add(new User(ds.getData()));
                        }
                        accessor.TeachersRetrieved(ConvertToTeachers(users));
                    } else {
                        Log.d(TAG, "No such users");
                    }
                } else {
                    Log.d(TAG, "get failed with ", task.getException());
                }
            }
        });
    }

    private List<Teacher> ConvertToTeachers(List<User> users){
        List<Teacher> teachers = new ArrayList<>();
        for (User user : users) {
            for (String subject : user.getSubjects()) {
                Teacher teacher = new Teacher(user, subject);
                teachers.add(teacher);
            }
        }
        return teachers;
    }

    //----------------------------GROUPS------------------------------

    private void CreateStudyGroup(StudyGroup group){
        //Add the user to the database
        db.collection("Users").document(group.getGroupID()).set(group)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "Group successfully created!");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error creating group", e);
                    }
                });
    }

    private void UpdateStudyGroup(StudyGroup group){
        //Add the user to the database
        db.collection("Users").document(group.getGroupID()).update("users", group.getUsers())
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "Group successfully updated!");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error updateing group", e);
                    }
                });
    }

    private void GetStudyGroup(String groupID, GroupAccessor accessor){
        DocumentReference docRef = db.collection("Groups").document(groupID);
        //User retrievedUser;
        docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        Log.d(TAG, "DocumentSnapshot data: " + document.getData());
                        StudyGroup result = new StudyGroup(document.getData());
                        accessor.GroupRetrieved(result);
                    } else {
                        Log.d(TAG, "No such document");
                    }
                } else {
                    Log.d(TAG, "get failed with ", task.getException());
                }
            }
        });
    }

    private void GetStudyGroups(GroupAccessor accessor){
        CollectionReference ref = db.collection("Groups");
        //User retrievedUser;
        ref.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    QuerySnapshot qs = task.getResult();
                    if (qs != null && !qs.isEmpty()) {
                        Log.d(TAG, "Retrieved groups");
                        List<StudyGroup> groups = new ArrayList<>();
                        for(DocumentSnapshot ds : qs.getDocuments()){
                            groups.add(new StudyGroup(ds.getData()));
                        }
                        accessor.GroupsRetrieved(groups);
                    } else {
                        Log.d(TAG, "No such groups");
                    }
                } else {
                    Log.d(TAG, "get failed with ", task.getException());
                }
            }
        });
    }

//    private List<StudyGroup> ConvertToUsers(List<StudyGroup> users){
//        List<StudyGroup> teachers = new ArrayList<>();
//        for (User user : users) {
//            for (String subject : user.getSubjects()) {
//                Teacher teacher = new Teacher(user, subject);
//                teachers.add(teacher);
//            }
//        }
//        return teachers;
//    }

    //----------------------------CHAT---------------------------------

    //Messages must be stored with the user as sender and teacher as recipient
    public void SendAndStoreMessage(Chat chat){
        // Read the input field and push a new instance
        // of ChatMessage to the Firebase database
        db.collection("Messages").document(chat.getChatID()).update("messageCount", chat.getMessageCount(), "messages", chat.getMessages()).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                Log.d(TAG, "Message successfully created!");
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Log.w(TAG, "Error creating message", e);
            }
        });
    }

    //Messages must be stored with the user as sender and teacher as recipient
    public void AddUserToContacts(Contact contact, String user){
        // Read the input field and push a new instance
        // of ChatMessage to the Firebase database
        db.collection("Contacts").document(user).collection("Contacts").document(contact.getEmail()).set(contact)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "Contact successfully created!");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error creating contact", e);
                    }
                });
    }

    public void GetUserContacts(String user, ContactAccessor accessor){
        CollectionReference colRef = db.collection("Contacts").document(user).collection("Contacts");

        colRef.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()){
                    Log.d(TAG, "Contacts query successful");
                    QuerySnapshot query = task.getResult();
                    if (query != null && !query.isEmpty()) {
                        Log.d(TAG, "Retrieved Contacts");
                        List<Contact> contacts = new ArrayList<>();
                        for(DocumentSnapshot ds : query.getDocuments()){
                            if(ds.getData() != null)
                                contacts.add(new Contact(ds.getData()));
                        }
                        accessor.ContactsRetrieved(contacts);
                    } else {
                        Log.d(TAG, "No such Contacts");
                    }
                } else {
                    Log.d(TAG, "Contacts query failed with ", task.getException());
                }
            }
        });
    }

//    /**
//     * It hashes the message_sent with the same id, to recover them more easily.
//     * The higher hashcode goes first.
//     * @param from
//     * @param to
//     * @return
//     */
//    public static String GetChatID(String from, String to){
//        long hashcodeFrom = from.hashCode();
//        long hashcodeTo = to.hashCode();
//        long result;
//
//        if (hashcodeFrom >= hashcodeTo){
//            result = (PRIME * hashcodeFrom) + hashcodeTo;
//        } else {
//            result = (PRIME * hashcodeTo) + hashcodeFrom;
//        }
//
//        return String.valueOf(result);
//    }

    public void GetAllUserChats(List<String> chatIDs, MessageAccessor accessor){

        for (String chatID : chatIDs) {
            db.collection("Messages").whereEqualTo("chatID", chatID).get()
                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()){
                                Log.d(TAG, "Contacts query successful");
                                QuerySnapshot query = task.getResult();
                                if (query != null && !query.isEmpty()) {
                                    Log.d(TAG, "Retrieved Contacts");
                                    for(DocumentSnapshot ds : query.getDocuments()){
                                        if(ds.getData() != null){
                                            Chat chat = new Chat(ds.getData());
                                            chat = FormatMessages(chat);
                                            accessor.MessagesRetrieved(chat);
                                        }
                                    }
                                } else {
                                    Log.d(TAG, "No such Contacts");
                                }
                            } else {
                                Log.d(TAG, "Contacts query failed with ", task.getException());
                            }
                        }
                    });
        }
    }

    public void CreateChat(Context context, Chat chat, String userEmail){
        //Add the chat to the database
        db.collection("Messages").document(chat.getChatID()).set(chat)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "Chat successfully created!");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error creating chat", e);
                    }
                });
    }

    public void GetMessages(String chatID, MessageAccessor accessor){
        DocumentReference ref = db.collection("Messages").document(chatID);

        ref.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()){
                    Log.d(TAG, "Messages query successful");
                    DocumentSnapshot ds = task.getResult();
                    if (ds != null && ds.getData() != null) {
                        Log.d(TAG, "Retrieved messages");
                        Chat chat = new Chat(ds.getData());
                        chat = FormatMessages(chat);
                        accessor.MessagesRetrieved(chat);
                    } else {
                        Log.d(TAG, "No such messages");
                    }
                } else {
                    Log.d(TAG, "Message query failed with ", task.getException());
                }
            }
        });
    }

    public void SetUpListener (Context context, RecyclerView recyclerView, String chatID, String userEmail) {
        DocumentReference ref = db.collection("Messages").document(chatID);

        ref.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException e) {
                if (e != null) {
                    Log.w(TAG, "listen:error", e);
                    return;
                }

                //Recover the chat in the database
                Chat chat = new Chat(documentSnapshot.getData());

                //Format all the messages inside of it
                chat = FormatMessages(chat);

                //Verify there is a cache chat
                if (((DataCache) context.getApplicationContext()).getChats() != null){

                    //Recover the cache chats
                    Chat cacheChat = ((DataCache) context.getApplicationContext()).GetChat(chatID);
                    if (cacheChat != null && cacheChat.getMessageCount() < chat.getMessageCount()) {

                        //Instantiate a new list of messages
                        List<ChatMessage> newMessages = new ArrayList<>();

                        //Recover the list of messages from the database
                        List<ChatMessage> recoveredMessages = chat.getMessages();

                        //Insert the new messages
                        for (int i = cacheChat.getMessageCount(); i < chat.getMessageCount(); i++){
                            //Store the instance temporarily
                            ChatMessage message = recoveredMessages.get(i);

                            //Inserting in the new list
                            newMessages.add(message);

                            //Inserting in the cache
                            ((DataCache) context.getApplicationContext()).AddMessageToChat(chatID, message);
                        }

                        //Notify the recycler that there are new messages
                        if (newMessages.size() != 0) {
                            //Call the method to reload the recycler view
                            ((MessageRecyclerViewAdapter) recyclerView.getAdapter()).MessageWasAdded(newMessages);

                            recyclerView.smoothScrollToPosition(chat.getMessageCount() - 1);
                        }
                    }
                } else {
                    //Recover the list of messages from the database
                    List<ChatMessage> recoveredMessages = chat.getMessages();

                    if (((DataCache) context.getApplicationContext()).getChats() == null){
                        ((DataCache) context.getApplicationContext()).setChats(new HashMap<>());
                    }

                    ((DataCache) context.getApplicationContext()).AddChat(chat);

                    //Notify the recycler that there are new messages
                    if (recoveredMessages.size() != 0) {
                        //Call the method to reload the recycler view
                        ((MessageRecyclerViewAdapter) recyclerView.getAdapter()).MessageWasAdded(recoveredMessages);

                        recyclerView.smoothScrollToPosition(chat.getMessageCount() - 1);
                    }
                }
            }
        });
    }

    private Chat FormatMessages(Chat chat){
        List<ChatMessage> msgs = new ArrayList<>();
        for (Object mp : chat.getMessages()) {
            ChatMessage msg = new ChatMessage((Map<String, Object>) mp);
            msgs.add(msg);
        }
        chat.setMessages(msgs);
        return chat;
    }
}
