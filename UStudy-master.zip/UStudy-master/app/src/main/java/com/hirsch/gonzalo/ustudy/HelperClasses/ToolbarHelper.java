package com.hirsch.gonzalo.ustudy.HelperClasses;

import android.app.Activity;
import android.content.Context;
import android.support.design.button.MaterialButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;

import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.hirsch.gonzalo.ustudy.Fragments.ChatListFragment;
import com.hirsch.gonzalo.ustudy.Fragments.MainMenuFragment;
import com.hirsch.gonzalo.ustudy.Fragments.ProfileEditFragment;
import com.hirsch.gonzalo.ustudy.Fragments.SignInFragment;
import com.hirsch.gonzalo.ustudy.Interfaces.NavigationHost;
import com.hirsch.gonzalo.ustudy.NavigationIconClickListener;
import com.hirsch.gonzalo.ustudy.R;

public class ToolbarHelper {

    private static FirebaseAuth mAuth;

    public static void SetUpToolbar(View view, Context context, AppCompatActivity activity, int viewID){
        Toolbar toolbar = view.findViewById(R.id.app_bar);
        //AppCompatActivity activity = (AppCompatActivity) getActivity();
        if (activity != null){
            activity.setSupportActionBar(toolbar);
        }
        toolbar.setNavigationOnClickListener(new NavigationIconClickListener(
                context,
                view.findViewById(viewID),
                new AccelerateDecelerateInterpolator(),
                context.getResources().getDrawable(R.drawable.menu),
                context.getResources().getDrawable(R.drawable.close_menu)));
    }

    public static void SetUpBar(View view, Activity activity, String recipientName){
        Toolbar toolbar = view.findViewById(R.id.app_bar);
        //AppCompatActivity activity = (AppCompatActivity) getActivity();
        toolbar.setTitle(recipientName);
        if (activity != null){
            ((AppCompatActivity)activity).setSupportActionBar(toolbar);
        }
    }

    public static void SetUpChatNavigation(Menu menu, Activity activity, String recipient){
        MenuItem arrow = menu.findItem(R.id.arrow_back);
        arrow.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                ((NavigationHost)activity).navigateTo(new ChatListFragment(), false);
                return true;
            }
        });
    }

    public static void SetUpToolbarNavigation(View view, final NavigationHost host, final Context context){
        //Get the firebase variables
        GetFirebase(context);

        //Set the log out button
        MaterialButton logOutButton = view.findViewById(R.id.menu_item_logout);
        logOutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Sign the user out
                mAuth.signOut();
                //Move to the log in
                host.navigateTo(new SignInFragment(), false);
            }
        });

        MaterialButton teachersButton = view.findViewById(R.id.menu_item_teachers);
        teachersButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Move to the main menu
                host.navigateTo(new MainMenuFragment(), false);
            }
        });

        MaterialButton chatButton = view.findViewById(R.id.menu_item_chat);
        chatButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Move to the main menu
                host.navigateTo(new ChatListFragment(), false);
            }
        });

        MaterialButton profileButton = view.findViewById(R.id.menu_item_profile);
        profileButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Move to the main menu
                host.navigateTo(new ProfileEditFragment(), false);
            }
        });
    }

    private static void GetFirebase(Context context){
        //Initialize the firebase app
        FirebaseApp.initializeApp(context);

        //Get reference to authentication
        mAuth = FirebaseAuth.getInstance();
    }
}
