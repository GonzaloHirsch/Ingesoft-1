package com.hirsch.gonzalo.ustudy.Adapters;

import android.app.Activity;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.hirsch.gonzalo.ustudy.DataTypes.Chat;
import com.hirsch.gonzalo.ustudy.DataTypes.Contact;
import com.hirsch.gonzalo.ustudy.DataTypes.Teacher;
import com.hirsch.gonzalo.ustudy.Fragments.ChatFragment;
import com.hirsch.gonzalo.ustudy.HelperClasses.DataCache;
import com.hirsch.gonzalo.ustudy.HelperClasses.DatabaseHelper;
import com.hirsch.gonzalo.ustudy.Interfaces.NavigationHost;
import com.hirsch.gonzalo.ustudy.ViewHolders.ProductCardViewHolder;
import com.hirsch.gonzalo.ustudy.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Adapter used to show a simple grid of products.
 */
public class ProductCardRecyclerViewAdapter extends RecyclerView.Adapter<ProductCardViewHolder> {

    private List<Teacher> teachers;
    private Activity activity;
    private String user;
    private String userName;
    private Context context;

    public ProductCardRecyclerViewAdapter(List<Teacher> teachers, Context context, Activity activity, String user, String userName) {
        this.teachers = teachers;
        this.activity = activity;
        this.user = user;
        this.userName = userName;
        this.context = context;
    }

    @NonNull
    @Override
    public ProductCardViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View layoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.product_card, parent, false);
        return new ProductCardViewHolder(layoutView);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductCardViewHolder holder, int position) {
        if (teachers != null && position < teachers.size()){
            Teacher teacher = teachers.get(position);
            holder.teacherName.setText(teacher.getUser().getFullName());
            holder.teacherSubject.setText(teacher.getSubject());
            holder.teacherUniversity.setText(teacher.getUser().getUniversity());
            holder.teacherAverage.setText(String.valueOf(teacher.getUser().getAverage()));
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //Set up the new fragment
                    ChatFragment chat = new ChatFragment();

                    String chatID = Chat.GetChatID(teacher.getUser().getEmail(), user);

                    if (((DataCache) context.getApplicationContext()).getContacts() == null){
                        ((DataCache) context.getApplicationContext()).setContacts(new ArrayList<>());
                    }
                    if (((DataCache) context.getApplicationContext()).getChats() == null){
                        ((DataCache) context.getApplicationContext()).setChats(new HashMap<>());
                    }

                    if (((DataCache) context.getApplicationContext()).getChats().get(chatID) == null){
                        chat.SetUp(chatID, teacher.getUser().getEmail(), teacher.getUser().getFullName(), true);

                        //Create the contact
                        Contact contact = new Contact(teacher.getUser().getEmail(), teacher.getUser().getFullName(), chatID);
                        Contact contactOther = new Contact(user, userName, chatID);

                        //Add the contact to each one of the parts
                        new DatabaseHelper(activity).AddUserToContacts(contact, user);
                        new DatabaseHelper(activity).AddUserToContacts(contactOther, teacher.getUser().getEmail());

                        if (((DataCache) context.getApplicationContext()).getContacts() == null){
                            ((DataCache) context.getApplicationContext()).setContacts(new ArrayList<>());
                        }
                        ((DataCache) context.getApplicationContext()).getContacts().add(contact);

                        ((NavigationHost)activity).navigateTo(chat, false);
                    } else {
                        chat.SetUp(chatID, teacher.getUser().getEmail(), teacher.getUser().getFullName(), false);

                        ((NavigationHost)activity).navigateTo(chat, false);
                    }
                }
            });
        }
        // TODO: Put ViewHolder binding code here in MDC-102
    }

    @Override
    public int getItemCount() {
        return teachers != null ? teachers.size() : 0;
    }
}
