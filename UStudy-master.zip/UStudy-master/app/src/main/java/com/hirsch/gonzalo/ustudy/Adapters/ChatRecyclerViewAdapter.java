package com.hirsch.gonzalo.ustudy.Adapters;

import android.app.Activity;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.hirsch.gonzalo.ustudy.DataTypes.Chat;
import com.hirsch.gonzalo.ustudy.ViewHolders.ChatViewHolder;
import com.hirsch.gonzalo.ustudy.DataTypes.Contact;
import com.hirsch.gonzalo.ustudy.Fragments.ChatFragment;
import com.hirsch.gonzalo.ustudy.HelperClasses.DatabaseHelper;
import com.hirsch.gonzalo.ustudy.Interfaces.NavigationHost;
import com.hirsch.gonzalo.ustudy.R;

import java.util.List;

public class ChatRecyclerViewAdapter extends RecyclerView.Adapter<ChatViewHolder> {

    private List<Contact> contacts;
    private Activity activity;
    private String userEmail;

    public ChatRecyclerViewAdapter(List<Contact> contacts, Activity activity, String userEmail) {
        this.contacts = contacts;
        this.activity = activity;
        this.userEmail = userEmail;
    }

    @NonNull
    @Override
    public ChatViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View layoutView = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.chat, viewGroup, false);
        return new ChatViewHolder(layoutView);
    }

    @Override
    public void onBindViewHolder(@NonNull ChatViewHolder chatViewHolder, int i) {
        if (contacts != null && i < contacts.size()){
            Contact contact = contacts.get(i);
            chatViewHolder.recipientName.setText(contact.getName());
            chatViewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //Set up the new fragment
                    ChatFragment chat = new ChatFragment();
                    chat.SetUp(Chat.GetChatID(contact.getEmail(), userEmail), contact.getEmail(), contact.getName(), false);
                    ((NavigationHost)activity).navigateTo(chat, false);
                }
            });
        }
    }

    @Override
    public int getItemCount()  {
        return contacts != null ? contacts.size() : 0;
    }
}
