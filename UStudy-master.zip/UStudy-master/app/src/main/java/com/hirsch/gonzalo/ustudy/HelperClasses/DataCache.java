package com.hirsch.gonzalo.ustudy.HelperClasses;

import android.app.Application;

import com.hirsch.gonzalo.ustudy.DataTypes.Chat;
import com.hirsch.gonzalo.ustudy.DataTypes.ChatMessage;
import com.hirsch.gonzalo.ustudy.DataTypes.Contact;
import com.hirsch.gonzalo.ustudy.DataTypes.Teacher;
import com.hirsch.gonzalo.ustudy.DataTypes.User;

import java.util.HashMap;
import java.util.List;

public class DataCache extends Application {

    private User user;
    private List<Teacher> teachers;
    private HashMap<String, List<Teacher>> teacherFilters;
    private HashMap<String, Chat> chats;
    private List<Contact> contacts;

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public List<Teacher> getTeachers() {
        return teachers;
    }

    public void setTeachers(List<Teacher> teachers) {
        this.teachers = teachers;
    }

    public HashMap<String, List<Teacher>> getTeacherFilters() {
        return teacherFilters;
    }

    public void InitializeChats(){
        chats = new HashMap<>();
    }

    public void AddChat(Chat chat){
        chats.put(chat.getChatID(), chat);
    }

    public void AddMessageToChat(String chatID, ChatMessage message){
        chats.get(chatID).AddMessage(message);
    }

    public Chat GetChat(String chatID){
        return chats.get(chatID);
    }

    public void AddContact(Contact contact){
        contacts.add(contact);
    }

    public List<Contact> getContacts() {
        return contacts;
    }

    public void setContacts(List<Contact> contacts) {
        this.contacts = contacts;
    }

    public void setTeacherFilters(HashMap<String, List<Teacher>> teacherFilters) {
        this.teacherFilters = teacherFilters;
    }

    public HashMap<String, Chat> getChats() {
        return chats;
    }

    public void setChats(HashMap<String, Chat> chats) {
        this.chats = chats;
    }
}
