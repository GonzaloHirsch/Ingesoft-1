package com.hirsch.gonzalo.ustudy.DataTypes;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.SortedSet;
import java.util.TreeSet;

public class Chat {

    private int messageCount;
    private List<ChatMessage> messages;
    private String chatID;

    public Chat(){

    }

    public Chat(String chatID){
        this.chatID = chatID;
        this.messages = new ArrayList<>();
        this.messageCount = 0;
    }

    public Chat(Map<String, Object> items){
        this.chatID = (String)items.get("chatID");
        this.messages = (ArrayList<ChatMessage>)items.get("messages");
        this.messageCount = ((Number)items.get("messageCount")).intValue();
    }

    public void AddMessage(ChatMessage message){
        this.messages.add(message);
        this.messageCount++;
    }

    public int getMessageCount() {
        return messageCount;
    }

    public void setMessageCount(int messageCount) {
        this.messageCount = messageCount;
    }

    public List<ChatMessage> getMessages() {
        return messages;
    }

    public void setMessages(List<ChatMessage> messages) {
        this.messages = messages;
    }

    public String getChatID() {
        return chatID;
    }

    public void setChatID(String chatID) {
        this.chatID = chatID;
    }

    public static String GetChatID(String from, String to){
        int hashcodeFrom = from.hashCode();
        int hashcodeTo = to.hashCode();
        int result;

        if (hashcodeFrom >= hashcodeTo){
            result = Objects.hash(hashcodeFrom, hashcodeTo);
        } else {
            result = Objects.hash(hashcodeTo, hashcodeFrom);
        }

        return String.valueOf(result);
    }
}
