package com.hirsch.gonzalo.ustudy.Fragments;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.TextInputEditText;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.hirsch.gonzalo.ustudy.DataTypes.Chat;
import com.hirsch.gonzalo.ustudy.DataTypes.ChatMessage;
import com.hirsch.gonzalo.ustudy.HelperClasses.DataCache;
import com.hirsch.gonzalo.ustudy.HelperClasses.DatabaseHelper;
import com.hirsch.gonzalo.ustudy.HelperClasses.ToolbarHelper;
import com.hirsch.gonzalo.ustudy.Interfaces.MessageAccessor;
import com.hirsch.gonzalo.ustudy.Adapters.MessageRecyclerViewAdapter;
import com.hirsch.gonzalo.ustudy.R;

public class ChatFragment extends Fragment implements MessageAccessor {

    //Firebase authentication
    private FirebaseAuth mAuth;
    //Tag for the log
    private final String TAG = "ChatFragment";

    private Chat chat;

    private TextInputEditText input;
    private RecyclerView recyclerView;
    private View fragmentView;

    private String chatID;
    private boolean newChat = true;
    private String recipientEmail;
    private String recipientName;

    private DataCache dataCache;

    public void SetUp(String chatID, String recipientEmail, String recipientName, boolean newchat){
        this.chatID = chatID;
        this.newChat = newchat;
        this.recipientEmail = recipientEmail;
        this.recipientName = recipientName;
    }

    @Override
    public void onCreate(Bundle savedInstance){
        super.onCreate(savedInstance);
        setHasOptionsMenu(true);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater menuInflater){
        menuInflater.inflate(R.menu.chat_menu, menu);
        ToolbarHelper.SetUpChatNavigation(menu, getActivity(), recipientName);
        super.onCreateOptionsMenu(menu, menuInflater);
    }

    @Override
    public void MessagesRetrieved(Chat chat) {
        this.chat = chat;
        if (this.chat == null){
            this.chat = new Chat(chatID);
        }
        SetUpGrid(fragmentView, chat);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        //Layout inflater for the view
        View view = inflater.inflate(R.layout.chat_fragment, container, false);
        this.fragmentView = view;

        //Items in the view
        recyclerView = view.findViewById(R.id.recycler_view);
        input = view.findViewById(R.id.input);

        //Retrieves the instance of the authentication
        mAuth = FirebaseAuth.getInstance();

        dataCache = (DataCache) getContext().getApplicationContext();

        //If the chat is new, dont try to load any messages
        //If it is new, it inserts a new reference in the database
        if (newChat){
            this.chat = new Chat(chatID);
            new DatabaseHelper(getContext()).CreateChat(getContext(), chat, mAuth.getCurrentUser().getEmail());
            dataCache.AddChat(this.chat);
            SetUpGrid(fragmentView, chat);
        } else {
            if (dataCache.getChats() != null && dataCache.GetChat(chatID) != null){
                this.chat = dataCache.GetChat(chatID);
                SetUpGrid(view, this.chat);
                //Move to the last message
                if (this.chat.getMessageCount() != 0){
                    recyclerView.smoothScrollToPosition(this.chat.getMessageCount() - 1);
                }
            } else {
                new DatabaseHelper(getContext()).GetMessages(chatID, this);
            }
        }

        input.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                recyclerView.smoothScrollToPosition(chat.getMessageCount() - 1);
            }
        });

        //Setting up the toolbar
        //ToolbarHelper.SetUpToolbarNavigation(view, (NavigationHost) getActivity(), getContext() );
        //ToolbarHelper.SetUpToolbar(view, getContext(), (AppCompatActivity) getActivity(), R.id.list_of_messages);
        ToolbarHelper.SetUpBar(view, getActivity(), recipientName);

        //Send message button
        FloatingActionButton fab = view.findViewById(R.id.send_button);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String messageText = input.getText().toString();

                FirebaseUser currentUser = mAuth.getCurrentUser();

                ChatMessage message = new ChatMessage(messageText, currentUser.getDisplayName(), currentUser.getEmail(), recipientEmail);
                chat.AddMessage(message);

                //Send the new message
                new DatabaseHelper(getContext()).SendAndStoreMessage(chat);
                dataCache.getChats().put(chatID, chat);

//                //Add the new message to the list
//                ((MessageRecyclerViewAdapter)recyclerView.getAdapter()).MessageWasAdded(message);
//
                recyclerView.smoothScrollToPosition(chat.getMessageCount() - 1);

                // Clear the input
                input.setText("");
            }
        });

        new DatabaseHelper(getContext()).SetUpListener(getContext(), recyclerView, chatID, mAuth.getCurrentUser().getEmail());

        recyclerView.smoothScrollToPosition(0);

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        //Initialize the firebase app
        FirebaseApp.initializeApp(getContext());
    }

    private void SetUpGrid(View view, Chat chat){
        RecyclerView recyclerView = view.findViewById(R.id.recycler_view);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(), 1, GridLayoutManager.VERTICAL, false));
        MessageRecyclerViewAdapter adapter = new MessageRecyclerViewAdapter(chat.getMessages(), getActivity(), mAuth.getCurrentUser().getEmail());
        recyclerView.setAdapter(adapter);
    }
}
