package com.hirsch.gonzalo.ustudy.Fragments;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.button.MaterialButton;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthActionCodeException;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseAuthWeakPasswordException;
import com.google.firebase.auth.FirebaseUser;
import com.hirsch.gonzalo.ustudy.DataTypes.User;
import com.hirsch.gonzalo.ustudy.HelperClasses.DatabaseHelper;
import com.hirsch.gonzalo.ustudy.HelperClasses.Validations;
import com.hirsch.gonzalo.ustudy.Interfaces.NavigationHost;
import com.hirsch.gonzalo.ustudy.Items.CustomSpinner;
import com.hirsch.gonzalo.ustudy.R;

public class ForgotPasswordFragment extends Fragment {

    //Firebase authentication
    private FirebaseAuth mAuth;
    //Tag for the log
    private final String TAG = "ForgotPasswordFragment";
    private String userEmail;

    private TextInputEditText emailEditText;
    private TextInputLayout emailLayout;
    private LinearLayout emailButtonLayout;
    private TextView errorLabel;


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        //Layout inflater for the view
        View view = inflater.inflate(R.layout.forgot_password_fragment, container, false);

        //Buttons
        MaterialButton backButtonCode = view.findViewById(R.id.back_button_code);
        MaterialButton sendEmailButton = view.findViewById(R.id.send_email_button);

        //Fields
        emailLayout = view.findViewById(R.id.username_layout);
        emailEditText = view.findViewById(R.id.username_content);

        errorLabel = view.findViewById(R.id.error_message);

        emailButtonLayout = view.findViewById(R.id.email_layout);

        UpdateUI();

        backButtonCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((NavigationHost)getActivity()).navigateTo(new SignInFragment(), false);
            }
        });
        sendEmailButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ValidateEmail()){
                    //Send the password reset email
                    SendResetEmail(userEmail);
                }
            }
        });

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        //Initialize the firebase app
        FirebaseApp.initializeApp(getContext());

        //Retrieves the instance of the authentication
        mAuth = FirebaseAuth.getInstance();
    }

    private void SendResetEmail(String email){
        mAuth.sendPasswordResetEmail(email).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                    errorLabel.setText(getText(R.string.email_sent));
                    errorLabel.setVisibility(View.VISIBLE);
                    Log.d(TAG, "Email sent.");
                } else {
                    errorLabel.setText(getText(R.string.ERROR_send_email));
                    errorLabel.setVisibility(View.VISIBLE);
                }
            }
        });
    }

    private void UpdateUI(){
        emailButtonLayout.setVisibility(View.VISIBLE);

        emailLayout.setVisibility(View.VISIBLE);
        emailEditText.setVisibility(View.VISIBLE);

        errorLabel.setVisibility(View.GONE);
    }

    private boolean ValidateEmail(){
        if (emailEditText.getText() != null){
            if (Validations.IsEmailValid(emailEditText.getText().toString())){
                userEmail = emailEditText.getText().toString();
                emailLayout.setErrorEnabled(false);
                return true;
            } else {
                emailLayout.setError(getString(R.string.ERROR_invalid_email));
                return false;
            }
        } else {
            emailLayout.setError(getString(R.string.ERROR_invalid_email));
            return false;
        }
    }

}
