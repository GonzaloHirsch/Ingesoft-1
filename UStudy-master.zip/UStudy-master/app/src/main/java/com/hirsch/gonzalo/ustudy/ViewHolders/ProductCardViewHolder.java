package com.hirsch.gonzalo.ustudy.ViewHolders;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.hirsch.gonzalo.ustudy.R;

public class ProductCardViewHolder extends RecyclerView.ViewHolder {

    public TextView teacherName;
    public TextView teacherSubject;
    public TextView teacherAverage;
    public TextView teacherUniversity;

    public ProductCardViewHolder(@NonNull View itemView) {
        super(itemView);
        teacherName = itemView.findViewById(R.id.teacher_name);
        teacherSubject = itemView.findViewById(R.id.teacher_subject);
        teacherAverage = itemView.findViewById(R.id.teacher_average);
        teacherUniversity = itemView.findViewById(R.id.teacher_university);
    }
}
