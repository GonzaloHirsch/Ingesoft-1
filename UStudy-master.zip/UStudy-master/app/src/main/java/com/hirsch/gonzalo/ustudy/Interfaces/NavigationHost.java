package com.hirsch.gonzalo.ustudy.Interfaces;

import android.support.v4.app.Fragment;

/**
 * Interface to navigate between Fragments
 */
public interface NavigationHost {

    void navigateTo(Fragment fragment, boolean addToBackStack);
}
