package com.hirsch.gonzalo.ustudy.Fragments;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.hirsch.gonzalo.ustudy.Adapters.ChatRecyclerViewAdapter;
import com.hirsch.gonzalo.ustudy.DataTypes.Chat;
import com.hirsch.gonzalo.ustudy.DataTypes.Contact;
import com.hirsch.gonzalo.ustudy.HelperClasses.DataCache;
import com.hirsch.gonzalo.ustudy.HelperClasses.DatabaseHelper;
import com.hirsch.gonzalo.ustudy.HelperClasses.ToolbarHelper;
import com.hirsch.gonzalo.ustudy.Interfaces.ContactAccessor;
import com.hirsch.gonzalo.ustudy.Interfaces.MessageAccessor;
import com.hirsch.gonzalo.ustudy.Interfaces.NavigationHost;
import com.hirsch.gonzalo.ustudy.R;

import java.util.HashMap;
import java.util.List;

public class ChatListFragment extends Fragment implements ContactAccessor, MessageAccessor {
    //Firebase authentication
    private FirebaseAuth mAuth;
    //Tag for the log
    private final String TAG = "ChatFragment";

    private List<Contact> contacts;
    private View view;

    private DataCache dataCache;

    @Override
    public void ContactsRetrieved(List<Contact> contacts) {
        //Recover all the contacts and set them in cache
        dataCache.setContacts(contacts);

        //Recover all the chat ids
        List<String> ids = Contact.GetContactIDs(contacts);

        if (contacts.size() > 0)
            SetUpGrid(this.view, this.contacts);

        //Recover all the chats and asign them to the hashmap
        new DatabaseHelper(getContext()).GetAllUserChats(ids, this);
    }

    @Override
    public void onCreate(Bundle savedInstance){
        super.onCreate(savedInstance);
        setHasOptionsMenu(true);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater menuInflater){
        menuInflater.inflate(R.menu.no_icons_menu, menu);
        super.onCreateOptionsMenu(menu, menuInflater);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        //Layout inflater for the view
        View view = inflater.inflate(R.layout.chat_list_fragment, container, false);

        //Store the view
        this.view = view;

        dataCache = (DataCache) getContext().getApplicationContext();

        //Retrieves the instance of the authentication
        mAuth = FirebaseAuth.getInstance();

        //Set up the toolbar
        ToolbarHelper.SetUpToolbarNavigation(view, (NavigationHost) getActivity(), getContext() );
        ToolbarHelper.SetUpToolbar(view, getContext(), (AppCompatActivity) getActivity(), R.id.list_of_chats);

        //Check if there are contacts in the cache
        //If not, retrieve them
        //If there are, load those
        if (dataCache.getContacts() == null){
            new DatabaseHelper(getContext()).GetUserContacts(mAuth.getCurrentUser().getEmail(), this);
        } else {
            SetUpGrid(view, dataCache.getContacts());
        }

        return view;
    }

    private void SetUpGrid(View view, List<Contact> contacts){
        RecyclerView recyclerView = view.findViewById(R.id.recycler_view);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(), 1, GridLayoutManager.VERTICAL, false));
        ChatRecyclerViewAdapter adapter = new ChatRecyclerViewAdapter(contacts, getActivity(), mAuth.getCurrentUser().getEmail());
        recyclerView.setAdapter(adapter);
    }

    @Override
    public void onStart() {
        super.onStart();

        //Initialize the firebase app
        FirebaseApp.initializeApp(getContext());
    }

    @Override
    public void MessagesRetrieved(Chat chat) {
        if (dataCache.getChats() == null){
            HashMap<String, Chat> chatHashMap = new HashMap<>();
            chatHashMap.put(chat.getChatID(), chat);
            dataCache.setChats(chatHashMap);
        } else {
            dataCache.AddChat(chat);
        }
    }
}
