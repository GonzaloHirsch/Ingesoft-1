package com.hirsch.gonzalo.ustudy.Fragments;

import android.support.v4.app.Fragment;

public class StudyGroupViewFragment extends Fragment {
}
