package com.hirsch.gonzalo.ustudy.Interfaces;

import com.hirsch.gonzalo.ustudy.DataTypes.Chat;
import com.hirsch.gonzalo.ustudy.DataTypes.ChatMessage;

import java.util.List;

public interface MessageAccessor {

    public void MessagesRetrieved(Chat chat);
}
