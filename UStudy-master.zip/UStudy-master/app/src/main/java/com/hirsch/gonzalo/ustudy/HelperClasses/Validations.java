package com.hirsch.gonzalo.ustudy.HelperClasses;

import java.util.regex.Pattern;

public class Validations {

    //Validates password length and if it contains a number
    public static boolean ValidatePassword(String password){
        if (password.length() < 8){
            return false;
        } else return ValidateContainsNumbers(password);
    }

    //Validates if the password contains any numbers
    public static boolean ValidateContainsNumbers(String password){
        boolean result = false;
        for (int i = 0; i < 10; i++){
            result = result || password.contains(String.valueOf(i));
        }
        return result;
    }

    public static boolean IsEmailValid(String email) {
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."+
                "[a-zA-Z0-9_+&*-]+)*@" +
                "(?:[a-zA-Z0-9-]+\\.)+[a-z" +
                "A-Z]{2,7}$";

        Pattern pat = Pattern.compile(emailRegex);
        return pat.matcher(email).matches();
    }

    public static boolean PasswordsAreEqualValidation(String password, String secondPassword){
        return password.equals(secondPassword);
    }

    //Validates the password confirmation
    public static boolean IsPasswordConfirmationValid(String password, String confirmPassword){
        return password.equals(confirmPassword);
    }


}
