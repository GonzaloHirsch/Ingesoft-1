package com.hirsch.gonzalo.ustudy.Interfaces;

import java.util.List;

public interface SubjectAccessor {
    public List<String> SubjectsRetrieved(List<String> subjects);
}
