package com.hirsch.gonzalo.ustudy.DataTypes;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class User {

    private String email;
    private String university;
    private String fullName;
    private double average;
    private List<String> subjects;
    private boolean isTeacher;

    public User(String email, String university, String fullName){
        this.email = email;
        this.university = university;
        this.fullName = fullName;
        this.subjects = new ArrayList<>();
        this.average = 0;
        this.isTeacher = false;
    }

    //Constructor used when data is retrieved from the database
    @SuppressWarnings("unchecked")
    public User(Map<String, Object> data){
        this.email = (String)data.get("email");
        this.university = (String)data.get("university");
        this.fullName = (String)data.get("fullName");
        this.subjects = (List<String>)data.get("subjects");
        this.average = (double)data.get("average");
        this.isTeacher = (boolean)data.get("teacher");
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        else if (!(obj instanceof User))
            return false;

        User user = (User) obj;
        return user.email.equals(this.email);
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    @Override
    public int hashCode() {
        return this.email.hashCode();
    }

    public String getEmail() {
        return email;
    }

    public String getUniversity() {
        return university;
    }

    public String getFullName() {
        return fullName;
    }

    public double getAverage() {
        return average;
    }

    public List<String> getSubjects() {
        return subjects;
    }

    public boolean isTeacher() {
        return isTeacher;
    }

    public void setAverage(double average) {
        this.average = average;
    }

    public void setTeacher(boolean teacher) {
        isTeacher = teacher;
    }

    public void setUniversity(String university) {
        this.university = university;
    }

    public boolean addSubject(String subject){
        return this.subjects.add(subject);
    }

    public boolean removeSubject(String subject){
        return this.subjects.remove(subject);
    }


}
