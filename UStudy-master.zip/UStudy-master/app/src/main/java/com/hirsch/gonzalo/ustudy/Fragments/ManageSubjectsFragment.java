package com.hirsch.gonzalo.ustudy.Fragments;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.hirsch.gonzalo.ustudy.DataTypes.Teacher;
import com.hirsch.gonzalo.ustudy.DataTypes.User;
import com.hirsch.gonzalo.ustudy.HelperClasses.DatabaseHelper;
import com.hirsch.gonzalo.ustudy.HelperClasses.ToolbarHelper;
import com.hirsch.gonzalo.ustudy.Interfaces.NavigationHost;
import com.hirsch.gonzalo.ustudy.Interfaces.SubjectAccessor;
import com.hirsch.gonzalo.ustudy.Interfaces.UserAccessor;
import com.hirsch.gonzalo.ustudy.Items.CustomSpinner;
import com.hirsch.gonzalo.ustudy.R;

import java.util.List;

public class ManageSubjectsFragment extends Fragment implements UserAccessor, SubjectAccessor {

    private User user;
    private List<Teacher> teachers;

    private FirebaseAuth mAuth;
    private FirebaseUser authenticatedUser;

    private List<String> availableSubjects;

    @Override
    public void UserRetrieved(User user) {
        //Store the user data
        this.user = user;

        //Set up the subjects
        new DatabaseHelper(getContext()).GetSubjects(this);
    }

    @Override
    public List<String> SubjectsRetrieved(List<String> subjects) {
        final List<String> userSubjects = user.getSubjects();
        for (String str: userSubjects) {
            subjects.remove(str);
        }
        this.availableSubjects = subjects;

        //Sets the dropdowns
        SetUpDropdown(getView(), getContext(), availableSubjects, "Avaliable Subjects", R.id.dropdown_available_subjects);
        SetUpDropdown(getView(), getContext(), userSubjects, "Your Subjects", R.id.dropdown_user_subjects);
        return subjects;
    }

    @Override
    public void TeachersRetrieved(List<Teacher> teachers) {
        this.teachers = teachers;
    }

    @Override
    public void onCreate(Bundle savedInstance){
        super.onCreate(savedInstance);
        setHasOptionsMenu(true);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater menuInflater){
        menuInflater.inflate(R.menu.no_icons_menu, menu);
        super.onCreateOptionsMenu(menu, menuInflater);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //Layout inflater for the view
        final View view = inflater.inflate(R.layout.manage_subjects_fragment, container, false);

        mAuth = FirebaseAuth.getInstance();

        // Get the signed user
        authenticatedUser = mAuth.getCurrentUser();

        ToolbarHelper.SetUpToolbarNavigation(view, (NavigationHost) getActivity(), getContext() );

        //Set up the toolbar
        ToolbarHelper.SetUpToolbar(view, getContext(), (AppCompatActivity) getActivity(), R.id.subjects_layout);

        //Dropdowns
        final CustomSpinner userSubjectDropdown = view.findViewById(R.id.dropdown_user_subjects);
        final CustomSpinner availableSubjectsDropdown = view.findViewById(R.id.dropdown_available_subjects);
        TextView messageTextAvailable = view.findViewById(R.id.message_text_available);
        TextView messageTextUser = view.findViewById(R.id.message_text_user);

        //Recover the signed user info
        new DatabaseHelper(getContext()).GetUser(authenticatedUser.getEmail(), this);

//        view.findViewById(R.id.a).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                ((NavigationHost)getActivity()).navigateTo(new ProfileEditFragment(), false);
//            }
//        });
        view.findViewById(R.id.add_subject_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (availableSubjectsDropdown.getSelectedItemPosition() == 0){
                    messageTextAvailable.setVisibility(View.VISIBLE);
                    messageTextAvailable.setText(getString(R.string.ERROR_no_available_subject_selected));
                } else {
                    messageTextAvailable.setVisibility(View.GONE);
                    user.addSubject((String)availableSubjectsDropdown.getSelectedItem());
                    user.getSubjects().remove(0);
                    availableSubjects.remove(availableSubjectsDropdown.getSelectedItem());
                    availableSubjects.remove(0);
                    new DatabaseHelper(getContext()).UpdateUser(user);
                    SetUpDropdown(view, getContext(), availableSubjects, "Avaliable Subjects", R.id.dropdown_available_subjects);
                    SetUpDropdown(view, getContext(), user.getSubjects(), "Your Subjects", R.id.dropdown_user_subjects);
                }
            }
        });
        view.findViewById(R.id.remove_subject_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (userSubjectDropdown.getSelectedItemPosition() == 0){
                    messageTextUser.setVisibility(View.VISIBLE);
                    messageTextUser.setText(getString(R.string.ERROR_no_user_subject_selected));
                } else {
                    messageTextUser.setVisibility(View.GONE);
                    user.removeSubject((String)userSubjectDropdown.getSelectedItem());
                    user.getSubjects().remove(0);
                    availableSubjects.add((String)userSubjectDropdown.getSelectedItem());
                    availableSubjects.remove(0);
                    new DatabaseHelper(getContext()).UpdateUser(user);
                    SetUpDropdown(view, getContext(), availableSubjects, "Avaliable Subjects", R.id.dropdown_available_subjects);
                    SetUpDropdown(view, getContext(), user.getSubjects(), "Your Subjects", R.id.dropdown_user_subjects);
                }
            }
        });

        return view;
    }

    private void SetUpDropdown(View view, Context context, List<String> subjects, String title, int idDropdown){
        //Set the title of the dropdown
        subjects.add(0, title);
        ArrayAdapter adapter = new ArrayAdapter<>(context, R.layout.dropdown_item_selected, subjects);
        adapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);

        final CustomSpinner spinner = view.findViewById(idDropdown);
        spinner.setAdapter(adapter);
        spinner.setSpinnerEventsListener(new CustomSpinner.OnSpinnerEventsListener() {
            public void onSpinnerOpened() {
                spinner.setSelected(true);
            }
            public void onSpinnerClosed() {
                spinner.setSelected(false);
            }
        });
    }

    @Override
    public void onStart() {
        super.onStart();

        //Initialize the firebase app
        FirebaseApp.initializeApp(getContext());


    }
}
