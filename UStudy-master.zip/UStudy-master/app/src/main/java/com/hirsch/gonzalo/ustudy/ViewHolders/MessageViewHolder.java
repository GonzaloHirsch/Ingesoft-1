package com.hirsch.gonzalo.ustudy.ViewHolders;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.hirsch.gonzalo.ustudy.R;

public class MessageViewHolder extends RecyclerView.ViewHolder {

    public TextView body;
    public TextView time;

    public MessageViewHolder(@NonNull View itemView) {
        super(itemView);
        body = itemView.findViewById(R.id.text_message_body);
        time = itemView.findViewById(R.id.text_message_time);
    }
}
